<%@page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- Sidebar — shows admin sidebar for admin/staff, customer sidebar for customers --%>

<%-- If user is admin or staff, delegate to admin sidebar --%>
<c:if test="${sessionScope.user.role == 'admin' or sessionScope.user.role == 'staff'}">
    <%@ include file="../admin/sidebar.jsp" %>
</c:if>

<%-- Customer sidebar — only shown for customer role --%>
<c:if test="${sessionScope.user.role == 'customer' or empty sessionScope.user}">
<style>
/* =======================
   GLOBAL
======================= */
body {
    background-color: #ffffff !important;
    color: #333;
}

/* =======================
   SIDEBAR
======================= */
.customer-sidebar {
    min-height: calc(100vh - 56px);
    background: #ffffff;
    position: sticky;
    top: 56px;
    height: calc(100vh - 56px);
    overflow-y: auto;
    border-right: 1px solid #e9ecef;
    padding: 10px;
}

/* LINK */
.customer-sidebar .nav-link {
    color: #333;
    border-radius: 10px;
    margin-bottom: 6px;
    padding: 0.55rem 0.9rem;
    font-size: 0.9rem;
    transition: all 0.2s ease;
}

/* 🔥 HOVER CHUẨN */
.customer-sidebar .nav-link:hover {
    background-color: #00537A !important;
    color: #ffffff !important;
}

/* Nút Logout riêng biệt khi hover */
.customer-sidebar .nav-link.text-danger:hover {
    background-color: #dc3545 !important; /* Nền đỏ */
    color: #ffffff !important;
    box-shadow: 0 3px 8px rgba(220, 53, 69, 0.25);
}

/* ICON khi hover */
.customer-sidebar .nav-link:hover i {
    color: #ffffff !important;
}

/* ACTIVE */
.customer-sidebar .nav-link.active {
    background: #00537A;
    color: #ffffff;
    font-weight: 500;
    box-shadow: 0 3px 8px rgba(0, 83, 122, 0.25);
}

/* ICON */
.customer-sidebar .nav-link i {
    width: 20px;
}

/* HEADING */
.sidebar-heading {
    color: #999;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    padding: 0.75rem 0.9rem 0.3rem;
}

/* =======================
   SCROLLBAR
======================= */
.customer-sidebar::-webkit-scrollbar {
    width: 6px;
}

.customer-sidebar::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 10px;
}
</style>

<nav class="col-md-3 col-lg-2 d-md-block customer-sidebar py-3 px-2">

    <div class="sidebar-heading">My Account</div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/dashboard') ? 'active' : ''}"
               href="${pageContext.request.contextPath}/dashboard">
                <i class="bi bi-speedometer2 me-2"></i>Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/customer') && param.action == 'profile' ? 'active' : ''}"
               href="${pageContext.request.contextPath}/customer?action=profile">
                <i class="bi bi-person-circle me-2"></i>My Profile
            </a>
        </li>
    </ul>

    <div class="sidebar-heading mt-2">Billing</div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/bill') ? 'active' : ''}"
               href="${pageContext.request.contextPath}/bill?action=mybill">
                <i class="bi bi-receipt me-2"></i>My Bills
            </a>
        </li>
    </ul>

    <div class="sidebar-heading mt-2">Contracts</div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/contract') && param.action != 'signContract' ? 'active' : ''}"
               href="${pageContext.request.contextPath}/contract?action=mycontract">
                <i class="bi bi-file-earmark-text me-2"></i>My Contracts
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link ${param.action == 'signContract' ? 'active' : ''}"
               href="${pageContext.request.contextPath}/contract?action=signContract">
                <i class="bi bi-pen me-2"></i>Sign Contract
            </a>
        </li>
    </ul>

    <div class="sidebar-heading mt-2">Services</div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/services') && empty param.action ? 'active' : ''}"
               href="${pageContext.request.contextPath}/services">
                <i class="bi bi-grid me-2"></i>Browse Services
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link ${param.action == 'myHistory' ? 'active' : ''}"
               href="${pageContext.request.contextPath}/services?action=myHistory">
                <i class="bi bi-clock-history me-2"></i>My Service History
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link ${param.action == 'requestService' || param.action == 'requestForm' ? 'active' : ''}"
               href="${pageContext.request.contextPath}/services?action=requestService">
                <i class="bi bi-send me-2"></i>Request Service
            </a>
        </li>
    </ul>

    <div class="sidebar-heading mt-2">Notifications</div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/notification') ? 'active' : ''}"
               href="${pageContext.request.contextPath}/notification?action=publicList">
                <i class="bi bi-bell me-2"></i>Notifications
            </a>
        </li>
    </ul>

    <div class="sidebar-heading mt-2">Rooms</div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/room') ? 'active' : ''}"
               href="${pageContext.request.contextPath}/room?action=categories">
                <i class="bi bi-house-door me-2"></i>Browse Rooms
            </a>
        </li>
    </ul>

    <div class="sidebar-heading mt-2">Account</div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link ${pageContext.request.requestURI.contains('/auth') && param.action == 'changePassword' ? 'active' : ''}"
               href="${pageContext.request.contextPath}/auth?action=changePassword">
                <i class="bi bi-shield-lock me-2"></i>Change Password
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-danger"
               href="${pageContext.request.contextPath}/auth?action=logout">
                <i class="bi bi-box-arrow-right me-2"></i>Logout
            </a>
        </li>
    </ul>

</nav>
</c:if>